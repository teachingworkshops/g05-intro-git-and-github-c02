# Story Character class (ex. Farmer, Blacksmith, etc)

class StoryCharacter:
    def __init__(self, name):
        self.name = name
        self.has_interacted = False