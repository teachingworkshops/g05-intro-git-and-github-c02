# g05-intro-git-and-github-c02

_Created By Group C02: Jake Rausch, Justin Kim, Ian MacDougall, & Brandon Norris_

*To run this game, downlaod the TaleOfTime zip, extract all, and run the 'Game_Test' Python File*

## Command to test code :
```bash
python Game_Test.py # Can comment out scene functions to run an individual scene
```

## Commands to update github:
```bash
git add .
git commit -m "<Description>"
git push
```

## Command to get the updated github:
```bash
git pull
```

